<?php
// Before removing this file, please verify the PHP ini setting `auto_prepend_file` does not point to this.

if (file_exists('/export/sd208/www/jp/r/e/gmoserver/0/9/sd0381509/oonavi.jp/wordpress-4.9.8-ja-jetpack_webfont-undernavicontrol/wp-content/plugins/wordfence/waf/bootstrap.php')) {
	define("WFWAF_LOG_PATH", '/export/sd208/www/jp/r/e/gmoserver/0/9/sd0381509/oonavi.jp/wordpress-4.9.8-ja-jetpack_webfont-undernavicontrol/wp-content/wflogs/');
	include_once '/export/sd208/www/jp/r/e/gmoserver/0/9/sd0381509/oonavi.jp/wordpress-4.9.8-ja-jetpack_webfont-undernavicontrol/wp-content/plugins/wordfence/waf/bootstrap.php';
}
?>